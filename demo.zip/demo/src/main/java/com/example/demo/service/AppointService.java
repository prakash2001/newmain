package com.example.demo.service;

import com.example.demo.entity.Appointment;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AppointService {

    ObjectMapper objectMapper = new ObjectMapper();

    public Appointment jsonToObject(String formJson) throws JsonProcessingException {
        Appointment formDetails = objectMapper.readValue(formJson, Appointment.class);
        return formDetails;
    }
}
