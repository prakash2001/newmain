package com.example.demo.controller;

import com.example.demo.entity.ApiResponce;
import com.example.demo.entity.Appointment;
import com.example.demo.repo.AppointmentRepo;
import com.example.demo.service.AppointService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class AppointmentController {

    @Autowired
    AppointmentRepo appointmentRepo;

    @GetMapping("/appoint")
    public String saveAppoint() {
        return "success";
    }

    @GetMapping("/check")
    public ApiResponce getmessage() {
        System.out.println("check url is called");
        return new ApiResponce("message", 200);
    }

    @PostMapping("/saveappoint")
    public List<Appointment> save(@RequestBody String appoint) throws JsonProcessingException {
        System.out.println(appoint);
        AppointService appointService = new AppointService();
        Appointment appointment = appointService.jsonToObject(appoint);
        appointmentRepo.save(appointment);
        List<Appointment> appoint1 = appointmentRepo.findAll();
        return appoint1;
    }
}
