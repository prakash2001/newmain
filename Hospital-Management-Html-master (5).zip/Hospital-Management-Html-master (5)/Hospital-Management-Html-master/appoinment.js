const sampleForm = document.getElementById("appoinmentform");
sampleForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  let form = e.currentTarget;

  var elements = document.getElementById("appoinmentform").elements;
    var obj ={};
    for(var i = 0 ; i < elements.length ; i++){
        var item = elements.item(i);
        console.log(item.value);
        obj[item.name] = item.value;
    }

  console.log(obj);
  const json = JSON.stringify(obj);
  console.log(json);
  try {
  const url="http://localhost:8081/saveappoint"
    saveappointment(url,json);

    console.log("this form is working****");
  } catch (error) {
    console.error(error);
  }
});

async function saveappointment(url,json)
{
  console.log(json);
  let fetchOptions = {
    
    method: "POST",
    
    headers: {
      "Content-Type": "application/json", 
      "Accept": "application/json"
    },
    body: json
   
  };

  const  res = await fetch(url, fetchOptions);
  console.log(res);
  const body = await res.json();
  console.log(body.message);  

  //  location.replace("newpage.html"); 
   
  if (!res.ok) {
    console.log("In error block");
    let error = await res.text();
    throw new Error(error);
  }
}